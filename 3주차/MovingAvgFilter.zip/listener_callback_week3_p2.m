function listener_callback_week3_p2(src,event)
    global data_stack time_stack angle angleavg

    if isempty(data_stack)
        data_stack = event.Data;
        time_stack = event.TimeStamps;
    else
        data_stack = [data_stack; event.Data]; %Voltage
        time_stack = [time_stack; event.TimeStamps]; %Time
    end
 
%%=======================================================2-1======================================================%
    N=5;
    Coefficient= [-45.7150440068524 109.957148575755];             %curve fit tool로 가져온 선형회귀 계수        
    angle= Coefficient(1,1)*data_stack+ Coefficient(1,2);          %전압과 그에 따른 각도에 대한 선형회귀 식
%      plot(time_stack, angle); grid on;                              %real time plotting
%      drawnow;
%%=======================================================2-2======================================================%
    if length(angle)<6
        angleavg(length(angle),1)= sum(angle(1:length(angle),1))/length(angle);
    else
        angleavg(length(angle),1)= (sum(angle((length(angle)-N+1):length(angle),1)))/N; %batch expression 형태
    end
    plot(time_stack,angle,'r-');grid on; hold on;
    plot(time_stack,angleavg,'b-');
    drawnow;
end 