function listener_callback_p1_1(src,event)
    global data_stack time_stack G_angle_stack A_angle_stack P_angle_stack CF_angle_stack % KF_angle_stack
    AxCoeff= [-5.03198383143487	10.1081256464420];
    AyCoeff= [5.20663428947808	-10.5484664475751];
    Coeff_potentiometer=[-69.2753765881297	177.265474096279]; %Derive from Polyfit potentiometervoltage and angle
    gyrobias= 1.38547734964082;  %Gyrobias should always be measured before test around 1.37~1.38 at 0 degree/s
    if isempty(data_stack)
        data_stack = event.Data;
        time_stack = event.TimeStamps;
        flag=0;
        gyro();
        accelerometer();
        potentiometer();
        complementaryfilter();
        %Kalman_filter();
        flag= flag+1;
    else
        data_stack = [data_stack; event.Data];                              %Voltage
        time_stack = [time_stack; event.TimeStamps];                        %Time
        gyro();
        accelerometer();
        potentiometer();
        complementaryfilter();
        %Kalman_filter();
    end
    plot(time_stack, G_angle_stack); hold on; grid on;
    plot(time_stack,P_angle_stack);
    plot(time_stack, CF_angle_stack);
end