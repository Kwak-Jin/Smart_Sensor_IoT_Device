%%StartForeground
%Project_1
clear all; close all; clc;
global data_stack time_stack G_angle_stack A_angle_stack P_angle_stack CF_angle_stack KF_angle_stack

mydaq= daq.createSession('ni');
mydaq.Rate= 100;                                   
mydaq.DurationInSeconds=10.0;
mydaq.NotifyWhenDataAvailableExceeds = mydaq.Rate/20;

ch2 = addAnalogInputChannel(mydaq,'Dev2',2,'Voltage'); %Gyroscope           data_stack(:,1)
ch1 = addAnalogInputChannel(mydaq,'Dev2',1,'Voltage'); %Accelerometer y     data_stack(:,2) 
ch4 = addAnalogInputChannel(mydaq,'Dev2',0,'Voltage'); %Accelerometer x     data_stack(:,3)
ch3 = addAnalogInputChannel(mydaq,'Dev2',3,'Voltage'); %Potentiometer       data_stack(:,4)
ch1(1).Range = [-10.0 10.0];
ch1(1).TerminalConfig = 'SingleEnded';
ch2(1).Range= [-10.0 10.0];
ch2(1).TerminalConfig = 'SingleEnded';
ch3(1).Range= [-10.0 10.0];
ch3(1).TerminalConfig = 'SingleEnded';
ch4(1).Range= [-10.0 10.0];
ch4(1).TerminalConfig = 'SingleEnded';

lh= addlistener(mydaq,'DataAvailable', @listener_callback_p1_1);
startForeground(mydaq);
%%

%Potentiometer Polyfit
Potentiometer=[-90 4.00700935355123; %Angle Voltage relationship
               -45 3.25398274464773;
                0  2.81758551869430;
                45 2.06566925902995;
                90 1.37177305202671];
Angle_P= Potentiometer(:,1);
Voltage= Potentiometer(:,2);
Coeff=[-69.2753765881297	187.265474096279];

%Accelerometer Calibration
Accelerometer = [-90  2.00772694032426  1.83316435178707;  %Ay= -9.81 Ax=0
         -45  1.86448237583808  1.89436853602298;
          0   1.81445520024459  2.02259372567270;  %Ay=   0   Ax=0
          45  1.86611508325163  2.15564075393041;
          90  2.01132399884476  2.22406493989152]; %Ay=  9.81 Ax=0
Angle_A= Accelerometer(:,1)*pi/180;
gx= cos(Angle_A);
Volx= Accelerometer(:,2);
gy=  sin(Angle_A);
Voly= Accelerometer(:,3);
AyCoeff= [-5.03198383143487	10.1081256464420];
AxCoeff= [5.20663428947808	-10.5484664475751];

%Gyroscope bias when stop
gyrobias=1.6;
%%
%Status check
figure(1); plot(time_stack,A_angle_stack); grid on;
title('Angle');
xlabel('Time [Sec]');
ylabel('Angle [degree]');
hold on; plot(time_stack,P_angle_stack,'r'); 
plot(time_stack,G_angle_stack,'b');
legend('Accelerometer','Potentiometer','Gyroscope');  
%%
% CF_angle_stack(1,1)=0;
% dt=1/ 100;
% T= 1;
% for i =2:length(P_angle_stack)
%     CF_angle_stack(i,1)= T/(T+dt) * CF_angle_stack(i-1,1) +dt/(T+dt) * A_angle_stack(i,1) + T/(T+dt) * (G_angle_stack(i,1)-G_angle_stack(i-1,1));
% end
% plot(time_stack,G_angle_stack,'b'); hold on; grid on;
% plot(time_stack,CF_angle_stack,'r'); 
% plot(time_stack,P_angle_stack,'c');
% legend('Gyro','CF','Potentiometer');
