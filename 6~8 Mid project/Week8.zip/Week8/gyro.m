global data_stack G_angle_stack
  G_avel_stack(1,1)= 0;
  G_angle_stack(1,1)=0;
  if flag==0
    for i=2:length(event.Data)
        dV= data_stack(i,1)-gyrobias;
        G_avel_stack(i,1)= dV*2000;                                       %Angular velocity
        G_angle_stack(i,1)= G_angle_stack(i-1,1)+G_avel_stack(i,1)*0.01;  %Numerical integration
    end
  else
    for i= length(data_stack)-length(event.Data) +1:length(data_stack)
        dV= data_stack(i,1)-gyrobias;
        G_avel_stack(i,1)= dV*2000;                                       %Angular velocity
        G_angle_stack(i,1)= G_angle_stack(i-1,1)+G_avel_stack(i,1)*0.01;  %Numerical integration
    end
  end           